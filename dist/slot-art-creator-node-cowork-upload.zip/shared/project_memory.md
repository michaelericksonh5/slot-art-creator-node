# Project Memory — Persistent State Across Sessions

Every slot-art-creator skill loads and updates a shared project state file
so locked decisions (theme, palette, key art path, asset registry) survive
Claude Code session restarts and conversation compaction.

This document describes the canonical state model. Every skill follows it.

---

## File layout

```
H:\Shared drives\Content Management - AI\Production_AI 2\Asset_Creation_Suite\
└── {GameID}_{username}\                          ← one project folder per game
    ├── project.json                              ← THE source of truth
    ├── game_brief.json                           ← human-readable brief mirror
    ├── Key_001.png, Key_002.png, ...             ← key art iterations
    ├── Sheet_001.png                             ← symbol contact sheets
    ├── HP1_001.png, HP1_002.png, ...             ← per-symbol iterations
    ├── HP2_001.png, MP1_001.png, LP1_001.png ...
    ├── BG_base_001.png, BG_freespins_001.png ... ← background variants
    ├── Bezel_001.png                             ← reel frame
    ├── HUD_001.png, Paytable_001.png             ← UI surfaces
    ├── Banner_big_001.png, Banner_mega_001.png   ← win banners by tier
    ├── Logo_hero_001.png, Logo_compact_001.png   ← logo lockups
    ├── QA_001.md                                 ← QA audit reports
    └── (no subfolders — flat structure for fast scanning)
```

Active project pointer (per-user, persists across sessions):

```
%USERPROFILE%\.h5g-slot-active-project.json   (Windows)
$HOME/.h5g-slot-active-project.json           (macOS/Linux)
```

This pointer file holds `{game_id, username, project_root, set_at}` so any
skill can find the active project without asking the user every time.

---

## `project.json` schema (canonical — every skill follows this)

```json
{
  "schema": "h5g_slot_project.v1",
  "game_id": "4470",
  "username": "merickson",
  "project_root": "H:\\Shared drives\\Content Management - AI\\Production_AI 2\\Asset_Creation_Suite\\4470_merickson",
  "created_at": "2026-05-06T15:30:00Z",
  "updated_at": "2026-05-06T16:45:00Z",

  "current_step": "key_art_locked",
  "next_step": "/slot-03-symbol-designer",

  "brief": { "...full game_brief.json contents..." },

  "style_anchor": {
    "key_art_path": "Key_003.png",
    "locked_at": "2026-05-06T16:00:00Z",
    "notes": "Approved by user — all downstream art reads this as visual reference"
  },

  "assets": {
    "key": {
      "iterations": ["Key_001.png", "Key_002.png", "Key_003.png"],
      "approved": "Key_003.png",
      "upscaled": null,
      "resized": []
    },
    "sheet": {
      "iterations": ["Sheet_001.png"],
      "approved": "Sheet_001.png",
      "upscaled": null
    },
    "symbols": {
      "HP1": {
        "iterations": ["HP1_001.png", "HP1_002.png"],
        "approved": "HP1_002.png",
        "upscaled": "HP1_002_4K.png",
        "resized": []
      },
      "HP2": { "iterations": [], "approved": null, "upscaled": null, "resized": [] },
      "MP1": { "iterations": [], "approved": null, "upscaled": null, "resized": [] },
      "LP1": { "iterations": [], "approved": null, "upscaled": null, "resized": [] },
      "WILD":    { "iterations": [], "approved": null, "upscaled": null, "resized": [] },
      "SCATTER": { "iterations": [], "approved": null, "upscaled": null, "resized": [] }
    },
    "backgrounds": {
      "base":      { "iterations": [], "approved": null, "upscaled": null, "resized": [] },
      "freespins": { "iterations": [], "approved": null, "upscaled": null, "resized": [] },
      "bonus":     { "iterations": [], "approved": null, "upscaled": null, "resized": [] },
      "pickme":    { "iterations": [], "approved": null, "upscaled": null, "resized": [] },
      "wheel":     { "iterations": [], "approved": null, "upscaled": null, "resized": [] }
    },
    "ui": {
      "bezel":      { "iterations": [], "approved": null, "upscaled": null },
      "hud":        { "iterations": [], "approved": null, "upscaled": null },
      "paytable":   { "iterations": [], "approved": null, "upscaled": null },
      "bonus_screen": { "iterations": [], "approved": null, "upscaled": null },
      "lobby_tile": { "iterations": [], "approved": null, "upscaled": null },
      "banners": {
        "small":  { "iterations": [], "approved": null },
        "medium": { "iterations": [], "approved": null },
        "big":    { "iterations": [], "approved": null },
        "mega":   { "iterations": [], "approved": null },
        "epic":   { "iterations": [], "approved": null }
      },
      "multipliers": {
        "x2": { "iterations": [], "approved": null },
        "x5": { "iterations": [], "approved": null }
      },
      "logos": {
        "hero":     { "iterations": [], "approved": null },
        "standard": { "iterations": [], "approved": null },
        "compact":  { "iterations": [], "approved": null }
      }
    },
    "qa_reports": ["QA_001.md"]
  },

  "gdd_source": {
    "file_id": null, "file_name": null, "drive_url": null,
    "version_extracted": null, "extracted_at": null
  }
}
```

### Asset record shape (the universal pattern)

Every asset slot follows this shape:

```json
{
  "iterations": ["File_001.png", "File_002.png"],   // every generation, in order
  "approved": "File_002.png",                       // null until user picks one
  "upscaled": "File_002_4K.png",                    // null until /slot-09 runs
  "resized": [                                      // empty until /slot-10 runs
    {"aspect": "16x9", "path": "File_002_resized_16x9.png"}
  ]
}
```

- `iterations` — append-only list of every generated filename for this slot. Never overwrite.
- `approved` — single filename the user picked as canonical for this slot. Null if not yet approved. Defaults to the latest iteration when ambiguous.
- `upscaled` — null until `/slot-09-upscaler` produces a 4K version of `approved`.
- `resized` — empty until `/slot-10-smart-resize` produces aspect variants.

For UI banner tiers and multiplier denominations and logo lockups, the
nested object holds one record per variant, each following the shape above
(with `upscaled`/`resized` optional since banners rarely need them).

### `current_step` and `next_step` vocabulary

`current_step` uses the exact name of the most recently completed step.
`next_step` is a slash command (with leading `/`) the user should run next.

| current_step | next_step | Set by |
|---|---|---|
| `gdd_loaded` | `/slot-01-game-brief` | slot-00-gdd-connect |
| `brief_locked` | `/slot-02-key-art` | slot-01-game-brief |
| `key_art_locked` | `/slot-03-symbol-designer` | slot-02-key-art |
| `symbols_in_progress` | `/slot-03-symbol-designer` (continue) or `/slot-04-symbol-sheet` | slot-03-symbol-designer |
| `sheet_locked` | `/slot-05-background-designer` | slot-04-symbol-sheet |
| `backgrounds_in_progress` | `/slot-05-background-designer` (continue) or `/slot-06-ui-designer` | slot-05-background-designer |
| `ui_in_progress` | `/slot-06-ui-designer` (continue) or `/slot-08-art-qa` | slot-06-ui-designer |
| `reskin_complete` | `/slot-08-art-qa` | slot-07-ui-reskin |
| `audit_complete` | `/slot-09-upscaler` (if audit GREEN) or specific design skill (if RED/YELLOW) | slot-08-art-qa |
| `upscale_in_progress` | `/slot-09-upscaler` (continue) or `/slot-10-smart-resize` | slot-09-upscaler |
| `delivery_complete` | (project done) | slot-10-smart-resize |

The `audit_complete` step's followup depends on the QA grade — included
in the QA report and the next-step nudge.

---

## Skill startup protocol

Every skill follows this exact sequence on invocation:

### Step 1: Find the active project

```
1. Did the user pass a GameID argument? (e.g., /slot-03-symbol-designer 4470)
   → Yes: use that GameID to construct project_root, update active-project pointer
   → No: read ~/.h5g-slot-active-project.json
        → File exists: use it
        → File missing: list folders in the asset suite and ask user to pick
                        OR offer to start a new project via /slot-01-game-brief
```

### Step 2: Load project.json

Read `{project_root}/project.json`. If it doesn't exist:
- Skill is `/slot-01-game-brief`: this is fine, you're creating it
- Any other skill: stop and tell the user to run `/slot-01-game-brief` first

### Step 3: Read the style anchor (the key art)

If `project.json.style_anchor.key_art_path` is set, read the image at
`{project_root}/{key_art_path}` using the Read tool. This image is the
visual ground truth for everything else generated. Pass it to NB2 as a
reference image when generating any new asset.

If style_anchor is NOT set and the current skill is anything other than
`/slot-01-game-brief` or `/slot-02-key-art`, warn the user that downstream
art will be less consistent without a locked key art and offer to run
`/slot-02-key-art` first.

### Step 4: Do the skill's actual work

Generate, edit, review, etc. — the skill's specific job.

### Step 5: Save outputs

Save generated images to the project_root with the correct naming
convention (see `shared/asset_naming.md`). Never overwrite — always
auto-increment.

### Step 6: Update project.json

After every generation:
- Append the new file path to the appropriate `assets[...]` array
- Update `updated_at`
- Update `current_step` and `next_step`
- Atomic write: write to `project.json.tmp`, then rename to `project.json`
  (avoids corruption if the write is interrupted, especially on Drive Stream)

### Step 7: Nudge the next step

Every skill ends its response with the next-step nudge:

```
✓ [Skill] complete.

Next: run `/slot-XX-skillname` to [what the next step does].
Type `/slot-` to see the full numbered workflow.
```

---

## Active-project pointer file

`~/.h5g-slot-active-project.json` holds:

```json
{
  "schema": "h5g_active_project.v1",
  "game_id": "4470",
  "username": "merickson",
  "project_root": "H:\\Shared drives\\Content Management - AI\\Production_AI 2\\Asset_Creation_Suite\\4470_merickson",
  "set_at": "2026-05-06T15:30:00Z"
}
```

Every skill that successfully resolves an active project writes/updates
this pointer. It survives Claude Code restart and conversation compaction.

A user can switch projects in two ways:
1. Pass a different GameID as a skill argument: `/slot-03-symbol-designer 4471`
2. Manually edit the pointer file (last resort)

---

## Path convention — relative in JSON, absolute at use time

All asset paths recorded in `project.json` are stored as **bare filenames
relative to `project_root`**. Examples:

```json
"style_anchor": { "key_art_path": "Key_003.png" }
"assets": {
  "key": { "iterations": ["Key_001.png", "Key_002.png", "Key_003.png"], "approved": "Key_003.png" },
  "symbols": { "HP1": { "approved": "HP1_002.png" } }
}
```

Why relative: the project folder stays portable. If a teammate copies
`H:\Shared drives\...\4470_merickson\` to a different drive, the
`project.json` still works — every filename resolves correctly against
the new `project_root`.

**At use time** — whenever you pass an asset path to:
- An MCP tool (`source`, `references`, `image`, etc. — `uploadLocalFile` does `fs.readFileSync` and needs absolute)
- A `Read` tool call (Read needs absolute path)
- A `Write` / save operation
- A child process that reads the file

… resolve to an absolute path first by joining with `project_root`:

```
absolute = path.join(project.project_root, project.style_anchor.key_art_path)
```

The `project_root` field in `project.json` IS stored as an absolute path
(it's the canonical project location), so resolution is one `path.join`
call. Skills that forget to resolve will silently fail with ENOENT or
have the MCP tool save to a wrong default folder.

When the MCP tool RETURNS a path, it returns absolute. Skills should
strip back to bare filename (using `path.basename`) before storing in
`project.json`, to keep the JSON portable.

## Atomic writes (Drive Stream safety)

Google Drive for Desktop / Drive Stream sometimes lags on file syncs.
To avoid corrupting `project.json` if a write is interrupted:

1. Read the existing `project.json` into memory
2. Modify in memory
3. Write to `project.json.tmp` in the same folder
4. Rename `project.json.tmp` → `project.json` (atomic on the same volume)

If a skill encounters a `.tmp` leftover from a previous crashed write,
warn the user and refuse to proceed until they decide whether to keep
the leftover or discard it.

---

## What happens after compaction

Conversation compaction discards the in-memory chat history but does not
touch any disk file. After compaction:

1. The user invokes any slot- skill
2. The skill follows the startup protocol above
3. `~/.h5g-slot-active-project.json` is read → project_root resolved
4. `project.json` is read → all locked decisions restored
5. The key art image is re-read into context as the visual anchor
6. Work continues as if nothing happened

The user does NOT need to re-establish theme, palette, style, or the
generated asset list. That's the entire point of project memory.

---

## What does NOT go in project memory

- API keys (handled by env vars / `setup-keys.js`)
- Generated image bytes (those live as PNGs on disk; `project.json` only stores paths)
- Per-image prompt history (each PNG gets its own `.meta.json` sidecar — see `shared/asset_naming.md`)
- Anything user-specific that isn't tied to this game project

---

## Style anchor management

The `style_anchor.key_art_path` field in `project.json` is what every
downstream skill reads as the visual ground truth. Three ways the user
controls it:

### 1. Approve at generation time (the default flow)

When `/slot-02-key-art` returns a generated image, it asks:

> Approve this as the locked key art, or iterate?

**On approve:** Claude sets `style_anchor.key_art_path = "Key_NNN.png"`,
records the timestamp, and writes `project.json`. Every later skill
auto-reads this file as a reference.

### 2. Switch the anchor later

The user can change which key art is the locked anchor at any time:

```
"Use Key_005 as the new anchor"
"Lock Key_002 instead — it had better palette"
```

Any skill processes that as a state edit:
- Confirm `Key_005.png` exists in the project folder
- Update `style_anchor.key_art_path = "Key_005.png"`
- Update `style_anchor.locked_at` to now
- Write `project.json` atomically

### 3. Override per generation

For one-off generations using a different reference (e.g., trying a
specific symbol against an experimental key art that isn't locked yet),
pass an explicit reference image:

```
"Generate HP1 using Key_007.png as reference instead of the locked anchor"
```

The skill passes that path to NB2's `reference_images` arg without
touching `project.json`. The locked anchor stays unchanged.

### Picking by visual review (any skill, any time)

The user can ask: "Show me Key_001, Key_003, and Key_005 — I want to pick
one to lock." Claude reads each image, presents them, and the user picks.

Filenames are the canonical identifier. Sidecars (`Key_NNN.meta.json`)
hold the prompt that produced each one — useful for "I liked iteration 3,
let me try a tweak of that prompt" workflows.

---

## Non-linear workflow

The numbered slash commands are a **recommendation**, not enforcement.
After the foundation is laid (brief locked + key art locked), the user
can jump between skills as needed:

- After key art, run `/slot-04-symbol-sheet` in **ideation mode** to
  brainstorm symbols visually before refining individuals
- Bounce between `/slot-03-symbol-designer` and `/slot-04-symbol-sheet`
  as you iterate
- Skip `/slot-04-symbol-sheet` entirely if you'd rather build symbols
  one at a time
- Run `/slot-05-background-designer` while symbols are still in flux
- Run `/slot-08-art-qa` at any checkpoint, not just at the end

Every skill's startup protocol detects what's already been done. They
adapt:
- If symbols don't exist yet, symbol-sheet runs in ideation mode
- If background isn't done yet, UI designer warns but proceeds
- If brief is missing, every skill stops and routes to `/slot-01-game-brief`

The only hard ordering constraint: **brief and key art must be locked
before any other generation skill runs.** Those two anchor everything.
