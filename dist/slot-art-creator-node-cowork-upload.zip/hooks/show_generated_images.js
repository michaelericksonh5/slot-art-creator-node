#!/usr/bin/env node
/**
 * PostToolUse hook — slot-art-creator-node
 *
 * Reads the tool result from stdin, extracts PNG paths from the text output,
 * and returns a systemMessage telling Claude to Read each path so the image
 * appears inline in the chat.
 */

import * as readline from "readline";

let raw = "";
const rl = readline.createInterface({ input: process.stdin, terminal: false });
rl.on("line", (line) => { raw += line + "\n"; });

rl.on("close", () => {
  try {
    const payload = JSON.parse(raw.trim());

    // tool_result is an array of {type, text} blocks
    const blocks = payload?.tool_result || [];
    const paths = [];

    for (const block of blocks) {
      if (block?.type !== "text") continue;
      const text = block?.text || "";
      // Extract lines like:  "    - C:\Users\...\image.png"
      for (const line of text.split("\n")) {
        const m = line.match(/^\s+-\s+(.+\.png)\s*$/i);
        if (m) paths.push(m[1].trim());
      }
    }

    if (!paths.length) {
      process.exit(0);
    }

    const msg =
      `Image(s) generated. Use the Read tool on each path to display them inline:\n` +
      paths.map((p) => `  Read(${JSON.stringify(p)})`).join("\n") +
      `\n\nAlways Read every path returned, not just the first one.`;

    process.stdout.write(JSON.stringify({ systemMessage: msg }));
  } catch {
    // Malformed payload — exit silently so we don't break the hook chain
    process.exit(0);
  }
});
